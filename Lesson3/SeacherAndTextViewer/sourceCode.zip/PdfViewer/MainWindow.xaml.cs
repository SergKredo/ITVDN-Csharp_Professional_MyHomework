﻿using System.IO;
using System.Windows;
using Microsoft.Win32;

namespace PdfViewer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void WindowLoaded(object sender, RoutedEventArgs e)
        {
            var location = System.Reflection.Assembly.GetExecutingAssembly().Location;
            var path = Path.Combine(System.IO.Path.GetDirectoryName(location), "sample.pdf");
            pdfViewer.LoadFile(path);
        }

        private void ButtonClick(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog {DefaultExt = ".pdf", Filter = "PDF documents (.pdf)|*.pdf"};
            dlg.ShowDialog();
            if (!string.IsNullOrEmpty(dlg.FileName))
            {
                txtFileLoaction.Text = dlg.FileName;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(txtFileLoaction.Text))
            {
                pdfViewer.LoadFile(txtFileLoaction.Text);
            }
        }
    }
}
